# AYBKK Hefei WS 2026 — Sticker Card Print Order

- Quantity: 54 cards. FRONT.png is the SAME front for all 54. Each HEFEI-###-B.png is that card's unique back. Pair FRONT with each back by filename.
- Final size: 85.6 × 54 mm (standard credit card). Files are 91.6 × 60 mm at 300 dpi = 3 mm bleed on all sides. Trim to 85.6 × 54.
- Corners: 3 mm radius, rounded.
- Hole punch: 5 mm round, top-center, 4 mm from trimmed top edge (a faint guide circle is printed on every file).
- Stock: 400 gsm, matte lamination BOTH sides (no gloss, no UV over the QR).
- Color: files are RGB; card purple is #582C83, QR ink #241243. Print QR side dark and crisp; do not lighten.
- IMPORTANT: do not scale, recolor, or sharpen the QR side. Test-scan one printed sample of any back before running the batch.
