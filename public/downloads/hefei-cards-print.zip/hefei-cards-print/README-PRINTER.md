# AYBKK Hefei WS 2026 — Sticker Card Print Order

- Quantity: 54 cards. FRONT.png is the SAME front for all 54. Each HEFEI-###-B.png is that card's unique back. Pair FRONT with each back by filename.
- Final size: 54 × 85.6 mm PORTRAIT (standard credit card, vertical). Files are 60 × 91.6 mm at 300 dpi = 3 mm bleed on all sides. Trim to 54 × 85.6.
- Corners: 3 mm radius, rounded.
- Hole punch: 5 mm round, top-center of the SHORT edge, punch center 5 mm below the trimmed top edge. No guide is printed on the artwork; the top 10 mm of every card is intentionally clear for the punch.
- Stock: 400 gsm, matte lamination BOTH sides (no gloss, no UV over the QR).
- Color: files are RGB; card purple is #582C83, QR ink #241243. Print QR side dark and crisp; do not lighten.
- IMPORTANT: do not scale, recolor, or sharpen the QR side. Test-scan one printed sample of any back before running the batch.
